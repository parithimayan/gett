//
//  loadingTableViewCell.swift
//  taskWisdomLeaf
//
//  Created by ilamparithi mayan on 23/06/24.
//

import UIKit
import SDWebImage


class loadingTableViewCell: UITableViewCell {
    
    @IBOutlet weak var viewUI: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var checkBoxButton: UIButton!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var picImage: UIImageView!
    
    var chkBoxTapped: (() -> Void)?

    var check = false

    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewUI.layer.masksToBounds = true
        viewUI.clipsToBounds = true
        viewUI.layer.cornerRadius = 5
        
        checkBoxButton.setImage(UIImage(named: "Uncheckbox"), for: .normal)
        checkBoxButton.setImage(UIImage(named: "CheckBox"), for: .selected)
        
    }
    
    
    func config(photo: PictureDetails, completion: @escaping() -> Void) {
        chkBoxTapped = completion
        self.picImage.image = nil
        let slno = Int(photo.id ?? "1") ?? 1
        
        // Set the title label with the photo's serial number and author.
        titleLbl.text = "\(slno+1) " + "\(photo.author ?? "None")"
        
        descriptionLbl.text = "Based on Mac OS, the operating system which runs Apple's line of Mac desktop and laptop computers, Apple iOS is designed for easy, seamless networking among a range of Apple products."
        descriptionLbl.numberOfLines = 0
        descriptionLbl.lineBreakMode = .byWordWrapping
        
//        "Apple iOS is the operating system for iPhone, iPad, and other Apple mobile devices." : "Based on Mac OS, the operating system which runs Apple's line of Mac desktop and laptop computers, Apple iOS is designed for easy, seamless networking among a range of Apple products."

        
        // Set the photo image if image data is available.
        if let imageURL = photo.download_url {
            picImage.sd_setImage(with: URL(string: imageURL), placeholderImage: UIImage(named: "wisdom"))
        }
    }

    @IBAction func checkBoxTapped(_ sender: Any) {
        checkBoxButton.isSelected.toggle()
        chkBoxTapped?()

    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
