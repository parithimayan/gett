//
//  Pics.swift
//  taskWisdomLeaf
//
//  Created by ilamparithi mayan on 23/06/24.
//

import UIKit
import Foundation


struct Pics {
    var id: String?
    var author: String?
    var picImageData: UIImage?
    var check: Bool? = false
}
